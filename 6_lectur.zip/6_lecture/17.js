//numbers sum
const numbers = [10, 20, 30, 40];

const sum = numbers.reduce((accumulator, current) => accumulator + current, 0);

console.log(sum);